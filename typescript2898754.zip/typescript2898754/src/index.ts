import { Estudiante } from "./Estudiante";
import recorrerEstudiantes from "./recorrerEstudiantes";
import { insertarEstudiante , actualizarEstudiante , borrarestudiante } from "./operaciones";

//definir objetos (literal) estudiante

const estudiante1: Estudiante = {
    nombre : " valeria",
    apellido : "melo",
    edad : 16,
    tipoIdentificacion : "TI",
    numeroIdentificacion : 232434
}

const estudiante2: Estudiante = {
    nombre : "carolina",
    apellido : "melo",
    edad : 18,
    tipoIdentificacion : "CC",
    numeroIdentificacion : 2342434
}

const estudiante3: Estudiante = {
    nombre : "tatiana",
    apellido : "avila",
    tipoIdentificacion : "cc",
    numeroIdentificacion : 34232434
}

// crear un arreglo de estudiantes

const listaEstudiante : Estudiante [] =[
    estudiante1,estudiante2,estudiante3
]
console.log(listaEstudiante);

//recorre el arrglo

recorrerEstudiantes(listaEstudiante);

//operaciones con arreglos

// se inserta un nuevo estudiante, se define como estudiante4 para que quede en lista de estudiantes, prueba console.log(lista estudiante)
 
console.log("------")
console.log("antes de insertar")
console.log(listaEstudiante)
insertarEstudiante(estudiante3 , listaEstudiante)
console.log("------")
console.log("despues de insertar")
console.log(listaEstudiante)
//actualizar 

//actualizarEstdiante(1(indice en el cual desea actualizar),listaEstudiante,"nombre nuevo", "apellido nuevo") console.log(listaEstudiante)

//Borrar borrarEstudiante(1,listaEstudiante) console.log(listaEstudiante)
console.log("------")
console.log("antes de borrar")
console.log(listaEstudiante)
borrarestudiante(1 ,listaEstudiante)
console.log("------")
console.log("despues de borrar")
console.log(listaEstudiante)