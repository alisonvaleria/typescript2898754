import { Estudiante } from './Estudiante';

export const insertarEstudiante = function (estudiante : Estudiante , arregloEstudiantes: Estudiante[]){
    //instruscciones para agregar (create) el estudiante al arreglo de estudiantes
    //metodo de Array en js permite insertar un elemento al arreglo 

    arregloEstudiantes.push(estudiante)
}

export const actualizarEstudiante = function (indice : number , nombre : string , apellido : string, listaEstudiantes : Estudiante[]){
    //instrucciones para actualizar el esrtudienta qeu se encuentre en el indice indicado en el parametro
}

export const borrarestudiante = function(indice:number, listaEstudiantes : Estudiante[]){
    //instrucciones para eliminar un elemento del arreglo que este en el indice del parametro

    // Verificar que el índice sea válido
    if (indice >= 0 && indice < listaEstudiantes.length) {
        // Eliminar el estudiante en el índice indicado
        listaEstudiantes.splice(indice, 1);
    } else {
        console.error('Índice fuera de rango');
    }
}